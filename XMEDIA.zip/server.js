const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const app = express();
const PORT = 6702;

// Set up storage for uploaded files
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        // Generate a random filename using crypto
        const randomName = crypto.randomBytes(16).toString('hex');
        const ext = path.extname(file.originalname);
        cb(null, `${randomName}${ext}`); // Combine random name with original file extension
    }
});

const upload = multer({ storage: storage });

// Set up view engine
app.set('view engine', 'ejs');

// Serve static files from the public directory
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use(express.urlencoded({ extended: true }));

// Render upload form
app.get('/', (req, res) => {
    res.render('index');
});

// Handle file upload
app.post('/upload', upload.single('videoFile'), (req, res) => {
    // Check if a file was uploaded
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded.' });
    }

    // Return success with the new filename
    res.json({ success: true, path: `/uploads/${req.file.filename}`, filename: req.file.filename });
});

// Render video player
// Render video player
app.get('/watch', (req, res) => {
    const videoPath = req.query.path;
    const filename = req.query.filename;
    const host = "23.27.211.158:6702"; // Get the host from the request

    if (!videoPath) {
        return res.status(400).send('Video not found');
    }
    res.render('publicPlayer', { videoPath, filename, host }); // Pass host to the template
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
